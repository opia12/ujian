const express = require('express');
const db = require('../config/db'); // Import koneksi database
const router = express.Router();


router.get('/posts', (req, res) => {
    const query = 'SELECT * FROM posts'; // Ganti dengan query Anda
    connection.query(query, (err, results) => {
        if (err) {
            console.error('Error fetching posts:', err);
            return res.status(500).send(err);
        }
        console.log('Fetched posts:', results); // Log untuk memverifikasi data yang diambil
        res.render('post', { posts: results || [] }); // Pastikan mengirim `results`
    });
});

// Menampilkan daftar postingan
router.get('/', (req, res) => {
    db.query('SELECT * FROM posts WHERE user_id = ?', [req.session.user.id], (err, results) => {
        if (err) throw err;
        res.render('post', { post: results });
    });
});

router.get('/post', (req, res) => {
    res.render('post'); // Pastikan ada file 'post.ejs' atau yang sesuai di folder 'views'
});

// Menampilkan form untuk membuat postingan baru
router.get('/create', (req, res) => {
    res.render('create');
});

// Menyimpan postingan baru ke database
router.post('/create', (req, res) => {
    const { title, content } = req.body;
    db.query('INSERT INTO posts (title, content, user_id) VALUES (?, ?, ?)', [title, content, req.session.user.id], (err, result) => {
        if (err) throw err;
        res.redirect('/post');
    });
});

// Menampilkan form untuk mengedit postingan
router.get('/edit/:id', (req, res) => {
    const postId = req.params.id;
    db.query('SELECT * FROM posts WHERE id = ?', [postId], (err, results) => {
        if (err) throw err;
        res.render('edit', { post: results[0] });
    });
});

// Mengupdate postingan
router.post('/edit/:id', (req, res) => {
    const postId = req.params.id;
    const { title, content } = req.body;
    db.query('UPDATE posts SET title = ?, content = ? WHERE id = ?', [title, content, postId], (err, result) => {
        if (err) throw err;
        res.redirect('/post');
    });
});

// Hapus postingan
router.get('/delete/:id', (req, res) => {
    const postId = req.params.id;
    console.log('Menghapus postingan dengan ID:', postId); // Log ID untuk debugging
    
    db.query('DELETE FROM posts WHERE id = ?', [postId], (err, results) => {
        if (err) {
            console.error('Kesalahan saat menghapus postingan:', err);
            return res.status(500).send('Terjadi kesalahan saat menghapus postingan.');
        }
        
        // Periksa apakah ada baris yang dihapus
        if (results.affectedRows === 0) {
            return res.status(404).send('Postingan tidak ditemukan.');
        }
        
        res.redirect('/'); // Redirect setelah penghapusan
    });
});

module.exports = router;