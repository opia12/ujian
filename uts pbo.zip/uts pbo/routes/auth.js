const express = require('express');
const bcrypt = require('bcrypt'); // Untuk hashing password
const db = require('../config/db'); // Import koneksi database
const router = express.Router();


// Menampilkan halaman registrasi
router.get('/register', (req, res) => {
    res.render('register');
});

router.post('/register', async (req, res) => {
    const { username, email, password } = req.body;

    // Validasi input
    if (!username || !email || !password) {
        return res.status(400).json({ error: 'Semua field harus diisi.' });
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(password, 10);

    // Cek apakah username atau email sudah ada
    db.query('SELECT * FROM users WHERE username = ? OR email = ?', [username, email], (err, results) => {
        if (err) {
            console.error('Error checking user:', err);
            return res.status(500).json({ error: 'Terjadi kesalahan saat memeriksa pengguna.' });
        }
        if (results.length > 0) {
            return res.status(400).json({ error: 'Username atau email sudah terdaftar.' });
        }

        // Simpan ke database
        db.query('INSERT INTO users (username, email, password) VALUES (?, ?, ?)', [username, email, hashedPassword], (err, results) => {
            if (err) {
                console.error('Error registering user:', err);
                return res.status(401).send('Invalid credentials.');
            }
            return res.redirect('/login'); // Redirect ke halaman postingan
        });
    });
});
router.get('/home', (req, res) => {
    res.render('home');
})
// Menampilkan halaman login
router.get('/login', (req, res) => {
    res.render('login');
});

// Menangani login pengguna
router.post('/login', (req, res) => {
    const { username, password } = req.body;
    db.query('SELECT * FROM users WHERE username = ?', [username], (err, results) => {
        if (err) throw err;

        if (results.length > 0) {
            const user = results[0];
            // Membandingkan password yang di-hash
            bcrypt.compare(password, user.password, (err, match) => {
                if (err) throw err;
                if (match) {
                    // Jika password cocok, buat sesi pengguna
                    req.session.user = {
                        id: user.id,
                        username: user.username
                    };
                    return res.redirect('/posts'); // Redirect ke halaman postingan
                } else {
                    return res.status(401).send('Invalid credentials.');
                }
            });
        } else {
            return res.status(401).send('Invalid credentials.');
        }
    });
});

// Menampilkan halaman profil
router.get('/profile', (req, res) => {
    const user = req.session.user;
    if (!user) {
        return res.redirect('/login');
    }
    db.query('SELECT * FROM users WHERE id = ?', [user.id], (err, results) => {
        if (err) {
            console.error('Error fetching user:', err);
            return res.status(500).json({ error: 'Terjadi kesalahan saat mengambil data pengguna.' });
        }
        res.render('profile', { user: results[0] });
    });
});

// Menangani pembaruan profil pengguna
router.post('/profile/update', async (req, res) => {
    const user = req.session.user;
    const { username, email, password } = req.body;

    if (!user) {
        return res.redirect('/login');
    }

    let hashedPassword = user.password;
    if (password) {
        hashedPassword = await bcrypt.hash(password, 10);
    }

    db.query('UPDATE users SET username = ?, email = ?, password = ? WHERE id = ?', [username, email, hashedPassword, user.id], (err, results) => {
        if (err) {
            console.error('Error updating user:', err);
            return res.status(500).json({ error: 'Terjadi kesalahan saat memperbarui data pengguna.' });
        }
        req.session.user.username = username; // Update session
        res.redirect('/profile');
    });
});

// Menangani penghapusan akun pengguna
router.post('/profile/delete', (req, res) => {
    const user = req.session.user;

    if (!user) {
        return res.redirect('/login');
    }

    db.query('DELETE FROM users WHERE id = ?', [user.id], (err, results) => {
        if (err) {
            console.error('Error deleting user:', err);
            return res.status(500).json({ error: 'Terjadi kesalahan saat menghapus akun.' });
        }
        req.session.destroy((err) => {
            if (err) throw err;
            res.redirect('/register'); // Redirect ke halaman registrasi setelah penghapusan
        });
    });
});
// Menangani logout pengguna
router.get('/logout', (req, res) => {
    req.session.destroy((err) => {
        if (err) throw err;
        res.redirect('/auth/login');
    });
});

module.exports = router;