const express = require('express');
const bodyParser = require('body-parser');
const session = require('express-session');
const authRoutes = require('./routes/auth');
const postsRoutes = require('./routes/posts'); 
const path = require('path');

const db = require('./config/db'); // Pastikan Anda memiliki konfigurasi database

const app = express();
const PORT = process.env.PORT || 3000;

app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

// Middleware untuk parsing body
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

// Middleware untuk sesi
app.use(session({
    secret: 'your_secret_key', // Ganti dengan kunci rahasia Anda
    resave: false,
    saveUninitialized: true,
}));

// Middleware untuk file statis (CSS, JS)
app.use(express.static(path.join(__dirname, 'public'))); // Folder 'public' untuk file statis

app.use((req, res, next) => {
    if (!req.session.user && req.path != '/auth/login' && req.path != '/auth/register' && req.path != '/auth/home' && req.path != '/posts/post') {
        
        return res.redirect('/auth/home');
    }
    next();
});

// Routes
app.use('/auth', authRoutes);
app.use('/posts', postsRoutes); // Use post routes


app.get('/', (req, res) => {
    if (req.session.user) {
        return res.redirect('/posts');
    } else {
        return res.redirect('/auth/login');
    }
});

app.use((req, res, next) => {
    console.log('Request URL:', req.url);
    next();
});

app.get('/posts', (req, res) => {
    connection.query('SELECT * FROM posts', (err, results) => {
        if (err) {
            console.error('Error fetching posts:', err);
            return res.status(500).send(err);
        }
        console.log('Fetched posts:', results);
        res.render('post', { posts: results || [] });
    });
});

// Jalankan server
app.listen(3000, () => {
    console.log(`Server is running on http://localhost:3000`);
});

// Error handling middleware
app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).send('Something broke!');
});

app.get('/post', (req, res) => {
    // Logika untuk mengambil postingan dari database
    db.query('SELECT * FROM posts', (err, results) => {
        if (err) {
            console.error('Kesalahan saat mengambil postingan:', err);
            return res.status(500).send('Terjadi kesalahan saat mengambil postingan.');
        }
        res.render('post', { post: results });
    });
});

app.use((req, res, next) => {
    res.status(404).send('Sorry, that route does not exist.');
});
const users = [];

// Endpoint untuk registrasi
app.post('/auth/register', async (req, res) => {
    const { username, email, password } = req.body;

    try {
        // Cek apakah pengguna sudah ada
        const existingUser  = users.find(user => user.username === username || user.email === email);
        if (existingUser ) {
            return res.send({ success: false, message: "Username or email already exists!" });
        }

        // Hash password
        const hashedPassword = await bcrypt.hash(password, 10);

        // Buat pengguna baru
        const newUser  = {
            username,
            email,
            password: hashedPassword
        };

        // Simpan pengguna ke array
        users.push(newUser );

        // Jika pendaftaran berhasil
        return res.send({ success: true, message: "User  registered successfully!", redirectUrl: "/auth/login" });
    } catch (error) {
        console.error(error);
        return res.send({ success: false, message: "Registration failed!" });
    }
});

app.get('/auth/profile', (req, res) => {
    res.sendFile(path.join(__dirname, 'path/to/profile'));
});

module.exports.ensureAuthenticated = function(req, res, next) {
    if (req.isAuthenticated()) {
        return next();
    }
    res.redirect('/auth/login');
};

